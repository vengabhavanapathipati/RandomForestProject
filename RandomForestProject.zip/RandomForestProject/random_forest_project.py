# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# Load dataset
import seaborn as sns
data = sns.load_dataset("titanic")

print("First 5 rows of dataset")
print(data.head())


# Check missing values
print("\nMissing values:")
print(data.isnull().sum())


# Handle missing values
data['age'] = data['age'].fillna(data['age'].mean())
data['embarked'] = data['embarked'].fillna(data['embarked'].mode()[0])

# Convert categorical to numeric
data = pd.get_dummies(data, columns=['sex'], drop_first=True)


# Select features

X = data[['pclass','age','sibsp','parch','fare']]
y = data['survived']


# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)


# Train Random Forest model
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)


# Predict
y_pred = rf.predict(X_test)


# Accuracy
print("\nAccuracy:", accuracy_score(y_test, y_pred))


# Classification report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Create confusion matrix
cm = confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix:")
print(cm)

# Plot the confusion matrix
plt.figure(figsize=(6,4))

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues',
    xticklabels=['Not Survived', 'Survived'],
    yticklabels=['Not Survived', 'Survived']
)

plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Random Forest Confusion Matrix")

plt.show()

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)

sns.heatmap(cm, annot=True, fmt='d')
plt.title("Confusion Matrix")
plt.show()


# Feature Importance
importances = rf.feature_importances_
features = X.columns

sns.barplot(x=importances, y=features)

plt.title("Feature Importance")
plt.show()